import { APIGatewayProxyEvent, Context, APIGatewayProxyResult } from "aws-lambda";
export declare const LoadData: (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
