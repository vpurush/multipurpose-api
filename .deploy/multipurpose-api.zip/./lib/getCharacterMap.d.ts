import { APIGatewayProxyEvent, Context, APIGatewayProxyResult, Callback } from "aws-lambda";
export declare type Handler<TEvent = any, TResult = any> = (event: TEvent, context: Context, callback: Callback<TResult>) => void | Promise<TResult>;
export declare const GetCharacterMap: (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
